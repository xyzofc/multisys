# Usage


```bash
example@bash ~ pip install multisys 
```

# Help

```bash
example@bash ~ multisys -h
```

# Command
```bash
example@bash ~ multisys build -h
example@bash ~ multisys new -h 
```